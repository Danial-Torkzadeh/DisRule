#!/bin/bash
# ============================================================
#  DisRule - double-click launcher for macOS
#  Double-click this file in Finder.
#  Libraries (~15 MB) go inside Python, not in this folder.
# ============================================================
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo ""
    echo " ============================================================"
    echo "  Python is not installed yet. One-time setup:"
    echo ""
    echo "  1. Open  https://www.python.org/downloads/"
    echo "  2. Click the big yellow 'Download Python' button"
    echo "     (it detects Mac automatically) and run the installer."
    echo "  3. When it finishes, double-click this file again."
    echo " ============================================================ "
    echo ""
    read -p "Press Enter to close this window..."
    exit 1
fi

# already satisfied?
if python3 -c "import reportlab, PIL" >/dev/null 2>&1; then
    python3 disrule_app.py
    echo ""
    read -p "Press Enter to close this window..."
    exit 0
fi

echo "One-time setup - downloading 2 small helper libraries (~15 MB)..."
if python3 -m pip install --disable-pip-version-check -r requirements.txt; then
    python3 disrule_app.py
    echo ""
    read -p "Press Enter to close this window..."
    exit 0
fi

# pip blocked (e.g. externally-managed Python) -> local .venv fallback
echo ""
echo "Direct install was blocked - using a local setup folder instead."
python3 -m venv .venv || { echo "Setup failed - screenshot this window."; read -p "Press Enter..."; exit 1; }
.venv/bin/pip install --quiet --disable-pip-version-check -r requirements.txt \
    || { echo "Download failed - check internet, then try again."; read -p "Press Enter..."; exit 1; }
.venv/bin/python disrule_app.py
echo ""
read -p "Press Enter to close this window..."
