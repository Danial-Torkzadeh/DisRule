#!/usr/bin/env python3
"""DisRule dashboard - build foldable statistical slide rules.

Run without arguments to open the desktop dashboard:

    python disrule_app.py

Or export headlessly from the command line:

    python disrule_app.py --dist t --df 7,14,28,35 --out my_rule
    python disrule_app.py --dist normal --half-width 50 --length 280 --out zrule

Exports <out>.pdf + <out>.svg + <out>.png.
"""
from __future__ import annotations

import argparse
import sys

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from disrule import DISTRIBUTIONS, RulerConfig, build_sheet, export_set, validate
from disrule.render import render_png_bytes

DIST_LABELS = {"normal": "Normal (z)", "t": "Student t",
               "chi2": "Chi-square", "f": "F distribution"}
DF_ROW_LABELS = ["FRONT line 1", "FRONT line 2", "FRONT line 3",
                 "BACK line 1", "BACK line 2", "BACK line 3"]

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except Exception:                                   # pragma: no cover
    HAS_PIL = False


# ==========================================================================
# headless build (used by CLI and by the GUI export)
# ==========================================================================

def make_config(args) -> RulerConfig:
    scale = 25.4 if args.unit == "in" else 1.0
    dfs = tuple(float(x) for x in args.df.split(",")) if args.df else ()
    spec = DISTRIBUTIONS[args.dist]
    if spec.needs_df and dfs:
        n = max(1, args.lines)
        need = 4 * n if spec.key == "f" else 2 * n
        if len(dfs) > need:
            # extra dfs: first N lines -> front, last N -> back
            if spec.key == "f":
                pairs = [dfs[2 * i:2 * i + 2] for i in range(len(dfs) // 2)]
                dfs = tuple(x for p in (pairs[:n] + pairs[-n:]) for x in p)
            else:
                dfs = tuple(dfs[:n]) + tuple(dfs[-n:])
    return RulerConfig(
        dist_key=args.dist,
        warp=args.warp,
        p_min=args.pmin, p_max=args.pmax,
        v_min=args.vmin, v_max=args.vmax,
        lines_per_half=args.lines,
        dfs=dfs,
        half_width_mm=args.half_width * scale,
        length_mm=args.length * scale,
        margin_mm=args.margin * scale,
        minors_per_major=args.minors,
        min_label_gap_mm=args.gap_label,
        min_minor_gap_mm=args.gap_minor,
        show_grid=not args.no_grid,
        highlight=not args.no_highlight,
        title=args.title or "",
        dpi=args.dpi,
    )


def run_cli(args) -> int:
    cfg = make_config(args)
    errs = validate(cfg)
    if errs:
        print("ERROR:", "; ".join(errs), file=sys.stderr)
        return 2
    try:
        sheet = build_sheet(cfg)
    except Exception as exc:                        # noqa: BLE001
        print("ERROR:", exc, file=sys.stderr)
        return 2
    written = export_set(sheet, args.out, dpi=cfg.dpi,
                         want=tuple(args.formats.split(",")))
    tot = sheet.stats["_totals"]
    print(f"built {cfg.dist_key} rule  sheet {cfg.length_mm:.0f} x "
          f"{2 * cfg.half_width_mm:.0f} mm  ->  ruler {cfg.length_mm:.0f} x "
          f"{cfg.half_width_mm:.0f} mm when folded")
    print(f"tick engine: {tot['labels']} labeled ticks, {tot['minors']} "
          f"minor ticks, min label gap {tot['min_label_gap_mm']:.1f} mm")
    for note in sheet.notes:
        print("note:", note)
    for p in written:
        print("wrote:", p)
    return 0


# ==========================================================================
# desktop dashboard
# ==========================================================================

class DisRuleApp:
    PREVIEW_PX = 1500          # raster width used for the preview image

    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("DisRule - statistical slide-rule generator")
        root.geometry("1320x780")
        root.minsize(1080, 640)

        self.v = {}
        self.df_vars = [[tk.StringVar() for _ in range(2)] for _ in range(6)]
        self.df_entries = [[None, None] for _ in range(6)]
        self.df_row_frames = []
        self._after_id = None
        self._photo = None
        self._pil = None
        self._sheet = None

        self._build_vars()
        self._build_ui()
        self._load_dist_defaults()
        root.after(120, self._refresh)

    # ---------------- vars ----------------
    def _build_vars(self):
        mk = lambda val: tk.StringVar(value=str(val))  # noqa: E731
        self.v = {
            "dist": tk.StringVar(value="t"),   # ALWAYS the internal key
            "warp": tk.StringVar(value="logit"),
            "pmin": mk("0.001"), "pmax": mk("0.999"),
            "vmin": mk("-5"), "vmax": mk("5"),
            "lines": tk.StringVar(value="2"),
            "unit": tk.StringVar(value="mm"),
            "halfw": mk("50"), "length": mk("280"), "margin": mk("8"),
            "minors": tk.StringVar(value="10"),
            "gapl": mk("3.2"), "gapm": mk("0.9"),
            "grid": tk.BooleanVar(value=True),
            "highlight": tk.BooleanVar(value=True),
            "title": mk(""), "dpi": mk("200"),
        }
        # the combobox shows the friendly LABEL and has its own variable;
        # v["dist"] only ever receives the internal key via _set_dist_key
        self._dist_label_var = tk.StringVar(
            value=DIST_LABELS[self.v["dist"].get()])

    # ---------------- UI ----------------
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=6)
        outer.pack(fill="both", expand=True)

        left = ttk.Frame(outer)
        left.pack(side="left", fill="y", padx=(0, 8))
        right = ttk.Frame(outer)
        right.pack(side="left", fill="both", expand=True)

        nb = ttk.Notebook(left)
        nb.pack(fill="both", expand=True)
        self.tab1 = ttk.Frame(nb, padding=8)
        self.tab2 = ttk.Frame(nb, padding=8)
        self.tab3 = ttk.Frame(nb, padding=8)
        nb.add(self.tab1, text=" Distribution ")
        nb.add(self.tab2, text=" Lines & df ")
        nb.add(self.tab3, text=" Sheet & ticks ")

        self._build_tab1(self.tab1)
        self._build_tab2(self.tab2)
        self._build_tab3(self.tab3)

        btns = ttk.Frame(left, padding=(0, 8, 0, 0))
        btns.pack(fill="x")
        ttk.Button(btns, text="Export PDF + SVG + PNG ...",
                   command=self._export).pack(fill="x")
        ttk.Button(btns, text="Refresh preview",
                   command=self._refresh).pack(fill="x", pady=(4, 0))

        self.status = tk.Label(right, text="building...", anchor="w",
                               justify="left", wraplength=1000)
        self.status.pack(side="bottom", fill="x", pady=(4, 0))

        # preview canvas with scrollbars
        pv = ttk.Frame(right)
        pv.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(pv, bg="#f0f0f0", highlightthickness=0)
        vs = ttk.Scrollbar(pv, orient="vertical", command=self.canvas.yview)
        hs = ttk.Scrollbar(pv, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        vs.pack(side="right", fill="y")
        hs.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)
        self.canvas.bind_all("<Button-4>", self._on_wheel)
        self.canvas.bind_all("<Button-5>", self._on_wheel)

        # trace everything
        for var in self.v.values():
            var.trace_add("write", self._schedule)
        for row in self.df_vars:
            for var in row:
                var.trace_add("write", self._schedule)

    def _row(self, parent, r, label):
        ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w",
                                           pady=2)
        return r

    def _build_tab1(self, f):
        r = 0
        ttk.Label(f, text="Distribution").grid(row=r, column=0, sticky="w")
        cb = ttk.Combobox(f, textvariable=self._dist_label_var,
                          state="readonly",
                          values=list(DIST_LABELS.values()), width=22)
        cb.grid(row=r, column=1, sticky="w", pady=2)
        cb.bind("<<ComboboxSelected>>",
                lambda _e: self._set_dist_key(cb.get()))
        self._dist_cb = cb
        r += 1

        ttk.Label(f, text="Probability warp").grid(row=r, column=0, sticky="w")
        ttk.Combobox(f, textvariable=self.v["warp"], state="readonly",
                     values=["logit", "linear"], width=10)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1

        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew",
                              pady=6)
        r += 1
        ttk.Label(f, text="P display range (both halves)").grid(
            row=r, column=0, columnspan=2, sticky="w")
        r += 1
        ttk.Label(f, text="P min").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["pmin"], width=10)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="P max").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["pmax"], width=10)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1

        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew",
                              pady=6)
        r += 1
        ttk.Label(f, text="Value range (user limit)").grid(
            row=r, column=0, columnspan=2, sticky="w")
        r += 1
        ttk.Label(f, text="v min").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["vmin"], width=10)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="v max").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["vmax"], width=10)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1

        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew",
                              pady=6)
        r += 1
        ttk.Label(f, text="Custom title (blank = auto)").grid(
            row=r, column=0, columnspan=2, sticky="w")
        r += 1
        ttk.Entry(f, textvariable=self.v["title"], width=28)\
            .grid(row=r, column=0, columnspan=2, sticky="we", pady=2)

    def _build_tab2(self, f):
        ttk.Label(f, text="Value lines per half").grid(row=0, column=0,
                                                       sticky="w")
        self.lines_spin = ttk.Spinbox(f, from_=1, to=3, width=5,
                                      textvariable=self.v["lines"])
        self.lines_spin.grid(row=0, column=1, sticky="w", pady=2)

        ttk.Label(f, text="df values - first N go to the FRONT half, "
                          "the rest to the BACK half").grid(
            row=1, column=0, columnspan=3, sticky="w", pady=(8, 2))
        self.df_grid = ttk.Frame(f)
        self.df_grid.grid(row=2, column=0, columnspan=3, sticky="w")
        for i, lab in enumerate(DF_ROW_LABELS):
            rf = ttk.Frame(self.df_grid)
            rf.grid(row=i, column=0, columnspan=3, sticky="w", pady=1)
            ttk.Label(rf, text=f"{lab}:", width=12).pack(side="left")
            e0 = ttk.Entry(rf, textvariable=self.df_vars[i][0], width=7)
            e0.pack(side="left", padx=(0, 2))
            self.df_entries[i][0] = e0
            l1 = ttk.Label(rf, text="x")
            l1.pack(side="left")
            e1 = ttk.Entry(rf, textvariable=self.df_vars[i][1], width=7)
            e1.pack(side="left", padx=(2, 0))
            self.df_entries[i][1] = e1
            self.df_row_frames.append(rf)
        self.f_label = ttk.Label(self.df_grid,
                                 text="F lines use (d1 x d2) pairs")
        self.f_label.grid(row=6, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Button(f, text="Swap front <-> back",
                   command=self._swap_halves).grid(row=0, column=2,
                                                   sticky="e", padx=(10, 0))

        ttk.Separator(f).grid(row=7, column=0, columnspan=3, sticky="ew",
                              pady=8)
        ttk.Checkbutton(f, text="Highlight key values (alpha marks, "
                                "integers, x5)",
                        variable=self.v["highlight"])\
            .grid(row=8, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(f, text="Show alignment grid", variable=self.v["grid"])\
            .grid(row=9, column=0, columnspan=3, sticky="w")

    def _build_tab3(self, f):
        r = 0
        ttk.Label(f, text="Units").grid(row=r, column=0, sticky="w")
        ttk.Combobox(f, textvariable=self.v["unit"], state="readonly",
                     values=["mm", "in"], width=6)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="Half width (folded ruler width)")\
            .grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["halfw"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="Sheet length (ruler length)")\
            .grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["length"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="Side margin").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["margin"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="(sheet prints as length x 2 x half width)")\
            .grid(row=r, column=0, columnspan=2, sticky="w")
        r += 1
        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew",
                              pady=6)
        r += 1
        ttk.Label(f, text="Dynamic tick engine").grid(
            row=r, column=0, columnspan=2, sticky="w")
        r += 1
        ttk.Label(f, text="Target minors per major").grid(row=r, column=0,
                                                          sticky="w")
        ttk.Spinbox(f, from_=2, to=20, width=5,
                    textvariable=self.v["minors"])\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="Min label gap (mm)").grid(row=r, column=0,
                                                     sticky="w")
        ttk.Entry(f, textvariable=self.v["gapl"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Label(f, text="Min minor gap (mm)").grid(row=r, column=0,
                                                     sticky="w")
        ttk.Entry(f, textvariable=self.v["gapm"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)
        r += 1
        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew",
                              pady=6)
        r += 1
        ttk.Label(f, text="PNG export dpi").grid(row=r, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v["dpi"], width=8)\
            .grid(row=r, column=1, sticky="w", pady=2)

    # ---------------- behaviour ----------------
    def _set_dist_key(self, label):
        """Translate a combobox label (or a raw key) into the internal key,
        then load that distribution's default value range and df rows."""
        key = None
        for k, lab in DIST_LABELS.items():
            if lab == label:
                key = k
                break
        if key is None and label in DISTRIBUTIONS:
            key = label
        if key is None or key == self.v["dist"].get():
            return
        self.v["dist"].set(key)
        self._load_dist_defaults()

    def _dist_key(self):
        """Internal distribution key, tolerant of stale label values."""
        val = self.v["dist"].get()
        if val in DISTRIBUTIONS:
            return val
        for k, lab in DIST_LABELS.items():
            if lab == val:
                return k
        return "t"

    def _load_dist_defaults(self):
        spec = DISTRIBUTIONS[self._dist_key()]
        rng = spec.default_value_range()
        self.v["vmin"].set(str(rng[0]))
        self.v["vmax"].set(str(rng[1]))
        dfs = spec.default_dfs()
        # reset the line count first so the df defaults land in active rows
        self.v["lines"].set("2" if spec.needs_df else "1")
        try:
            n_lines = 1 if not spec.needs_df else \
                max(1, min(3, int(float(self.v["lines"].get()))))
        except ValueError:
            n_lines = 2
        # active rows: front 0..n-1 and back 3..3+n-1 - fill THOSE rows only
        active_rows = list(range(n_lines)) + list(range(3, 3 + n_lines))
        for i in range(6):
            vals = ["", ""]
            if spec.needs_df and i in active_rows:
                k = active_rows.index(i)
                if spec.dfs_per_line == 1:
                    if k < len(dfs):
                        vals[0] = str(int(dfs[k])) if dfs[k] == int(dfs[k]) \
                            else str(dfs[k])
                else:
                    if 2 * k + 1 < len(dfs):
                        vals = [str(int(dfs[2 * k])),
                                str(int(dfs[2 * k + 1]))]
            self.df_vars[i][0].set(vals[0])
            self.df_vars[i][1].set(vals[1])
        self._sync_df_states()

    def _sync_df_states(self):
        spec = DISTRIBUTIONS[self._dist_key()]
        normal = spec.key == "normal"
        is_f = spec.key == "f"
        try:
            lines = 1 if normal else max(1, min(3, int(self.v["lines"].get())))
        except ValueError:
            lines = 2
        self.lines_spin.configure(state="disabled" if normal else "normal")
        self.f_label.configure(
            text="F lines use (d1 x d2) pairs" if is_f else
                 ("no degrees of freedom for the normal rule"
                  if normal else ""))
        for i in range(6):
            active = spec.needs_df and (i < lines or 3 <= i < 3 + lines)
            st = "normal" if active else "disabled"
            self.df_entries[i][0].configure(state=st)
            self.df_entries[i][1].configure(state=st if is_f else "disabled")
            kids = self.df_row_frames[i].winfo_children()
            # kids: [row label, entry0, 'x' label, entry1]
            if len(kids) >= 4:
                kids[2].configure(text="x" if is_f else " ")
                kids[3].configure(width=7 if is_f else 1)

    def _swap_halves(self):
        for c in range(2):
            for i in range(3):
                a = self.df_vars[i][c].get()
                b = self.df_vars[3 + i][c].get()
                self.df_vars[i][c].set(b)
                self.df_vars[3 + i][c].set(a)

    def _schedule(self, *_a):
        if self._after_id:
            try:
                self.root.after_cancel(self._after_id)
            except Exception:                           # noqa: BLE001
                pass
        self._after_id = self.root.after(280, self._refresh)

    def _collect_config(self):
        errs = []
        num = {}
        for key in ("pmin", "pmax", "vmin", "vmax", "halfw", "length",
                    "margin", "gapl", "gapm", "dpi"):
            try:
                num[key] = float(self.v[key].get())
            except ValueError:
                errs.append(f"'{key}' must be a number")
                num[key] = 0.0
        try:
            minors = int(float(self.v["minors"].get()))
        except ValueError:
            errs.append("'minors' must be an integer")
            minors = 10
        try:
            lines = int(float(self.v["lines"].get()))
        except ValueError:
            errs.append("'lines per half' must be 1..3")
            lines = 2

        spec = DISTRIBUTIONS[self._dist_key()]
        normal = spec.key == "normal"
        is_f = spec.key == "f"
        n = 1 if normal else lines
        dfs = []
        if spec.needs_df:
            rows = list(range(n)) + list(range(3, 3 + n))
            for i in rows:
                for c in range(2):
                    if c == 1 and not is_f:
                        continue
                    raw = self.df_vars[i][c].get().strip()
                    try:
                        dfs.append(float(raw))
                    except ValueError:
                        errs.append(f"df in row '{DF_ROW_LABELS[i]}' "
                                    f"({'d2' if c else 'd1'}) is not a number")
        scale = 25.4 if self.v["unit"].get() == "in" else 1.0
        cfg = RulerConfig(
            dist_key=spec.key,
            warp=self.v["warp"].get(),
            p_min=num.get("pmin", 0.001), p_max=num.get("pmax", 0.999),
            v_min=num.get("vmin", -5), v_max=num.get("vmax", 5),
            lines_per_half=n,
            dfs=tuple(dfs),
            half_width_mm=num.get("halfw", 50) * scale,
            length_mm=num.get("length", 280) * scale,
            margin_mm=num.get("margin", 8) * scale,
            minors_per_major=minors,
            min_label_gap_mm=num.get("gapl", 3.2),
            min_minor_gap_mm=num.get("gapm", 0.9),
            show_grid=self.v["grid"].get(),
            highlight=self.v["highlight"].get(),
            title=self.v["title"].get(),
            dpi=int(num.get("dpi", 200)) or 200,
        )
        errs.extend(validate(cfg))
        return cfg, errs

    def _refresh(self, *_a):
        self._after_id = None
        cfg, errs = self._collect_config()
        if errs:
            self._set_status("fix: " + "; ".join(errs[:3]), error=True)
            return
        try:
            sheet = build_sheet(cfg)
        except Exception as exc:                        # noqa: BLE001
            self._set_status(f"cannot build: {exc}", error=True)
            return
        self._sheet = sheet
        if HAS_PIL:
            buf = render_png_bytes(sheet, target_width_px=self.PREVIEW_PX)
            self._pil = Image.open(buf)
            self._draw_preview()
        tot = sheet.stats["_totals"]
        msg = (f"{tot['labels']} labeled ticks, {tot['minors']} minor ticks, "
               f"min label gap {tot['min_label_gap_mm']:.1f} mm  |  "
               f"sheet {sheet.width_mm:.0f} x {sheet.height_mm:.0f} mm -> "
               f"folded ruler {sheet.width_mm:.0f} x "
               f"{sheet.height_mm / 2:.0f} mm (front + back)")
        if sheet.notes:
            msg += "  |  " + " / ".join(sheet.notes[:2])
        self._set_status(msg)

    def _draw_preview(self):
        if self._pil is None:
            return
        cw = max(self.canvas.winfo_width(), 200)
        img = self._pil
        scale = min(1.0, cw / img.width)
        disp = img.resize((max(1, int(img.width * scale)),
                           max(1, int(img.height * scale))),
                          Image.LANCZOS)
        self._photo = ImageTk.PhotoImage(disp)
        self.canvas.delete("all")
        self.canvas.create_image(8, 8, image=self._photo, anchor="nw")
        self.canvas.configure(scrollregion=(0, 0, disp.width + 16,
                                            disp.height + 16))

    def _on_canvas_resize(self, _e):
        if self._pil is not None:
            self._draw_preview()

    def _on_wheel(self, e):
        step = -1 if getattr(e, "delta", 0) > 0 or e.num == 4 else 1
        self.canvas.yview_scroll(step, "units")

    def _set_status(self, text, error=False):
        self.status.configure(
            text=text, fg="#b02020" if error else "#222222")

    def _export(self):
        cfg, errs = self._collect_config()
        if errs:
            messagebox.showerror("DisRule", "Fix these first:\n- " +
                                 "\n- ".join(errs[:6]))
            return
        try:
            sheet = build_sheet(cfg)
        except Exception as exc:                        # noqa: BLE001
            messagebox.showerror("DisRule", str(exc))
            return
        unit = self.v["unit"].get()
        initial = (f"{cfg.dist_key}_disrule_"
                   f"{cfg.half_width_mm:.0f}x{cfg.length_mm:.0f}mm")
        path = filedialog.asksaveasfilename(
            title="Export DisRule", defaultextension=".pdf",
            initialfile=initial,
            filetypes=[("PDF file", "*.pdf"), ("All files", "*.*")])
        if not path:
            return
        base = path[:-4] if path.lower().endswith(".pdf") else path
        try:
            written = export_set(sheet, base, dpi=cfg.dpi)
        except Exception as exc:                        # noqa: BLE001
            messagebox.showerror("DisRule", f"export failed: {exc}")
            return
        tot = sheet.stats["_totals"]
        msg = ("Exported:\n- " + "\n- ".join(written) +
               f"\n\n{tot['labels']} labeled ticks, {tot['minors']} minor "
               f"ticks.\nPrint at 100% scale (no 'fit to page'), then fold "
               f"the BACK half behind the FRONT half along the dashed line.")
        messagebox.showinfo("DisRule - exported", msg)


def run_gui():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("clam")
    except Exception:                                   # noqa: BLE001
        pass
    DisRuleApp(root)
    root.mainloop()


def build_parser():
    p = argparse.ArgumentParser(
        prog="disrule_app.py",
        description="Generate foldable statistical slide rules "
                    "(DisRule). Run without arguments for the GUI.")
    p.add_argument("--dist", default="t",
                   choices=list(DIST_LABELS.keys()))
    p.add_argument("--warp", default="logit", choices=["logit", "linear"])
    p.add_argument("--pmin", type=float, default=0.001)
    p.add_argument("--pmax", type=float, default=0.999)
    p.add_argument("--vmin", type=float, default=None)
    p.add_argument("--vmax", type=float, default=None)
    p.add_argument("--lines", type=int, default=2,
                   help="value lines per half (1-3)")
    p.add_argument("--df", default=None,
                   help="comma separated dfs; t/chi2 need 2*lines, "
                        "F needs 4*numbers")
    p.add_argument("--half-width", type=float, default=50.0)
    p.add_argument("--length", type=float, default=280.0)
    p.add_argument("--margin", type=float, default=None,
                   help="side margin (default: 8 mm or 0.3 in)")
    p.add_argument("--unit", default="mm", choices=["mm", "in"])
    p.add_argument("--minors", type=int, default=10,
                   help="target unmarked ticks between labeled ticks")
    p.add_argument("--gap-label", type=float, default=3.2)
    p.add_argument("--gap-minor", type=float, default=0.9)
    p.add_argument("--no-grid", action="store_true")
    p.add_argument("--no-highlight", action="store_true")
    p.add_argument("--title", default="")
    p.add_argument("--dpi", type=int, default=200)
    p.add_argument("--formats", default="pdf,svg,png")
    p.add_argument("--out", default=None, help="output base path (no ext)")
    p.add_argument("--gui", action="store_true")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    spec = DISTRIBUTIONS[args.dist]
    if args.vmin is None or args.vmax is None:
        rng = spec.default_value_range()
        args.vmin = args.vmin if args.vmin is not None else rng[0]
        args.vmax = args.vmax if args.vmax is not None else rng[1]
    if args.df is None:
        args.df = ",".join(str(d) for d in spec.default_dfs())
    if args.margin is None:
        args.margin = 0.3 if args.unit == "in" else 8.0
    if args.out:
        return run_cli(args)
    return run_gui()


if __name__ == "__main__":
    sys.exit(main())
