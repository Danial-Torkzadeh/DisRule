# DisRule — foldable statistical slide-rule generator

A Python tool that generates **foldable paper slide rules for probability
distributions**. Pick a distribution, set the degrees of freedom, preview it
instantly, and export a print-ready sheet whose two halves fold into a
double-sided ruler — one face per half, each with its own P line.

Supports: **Normal (z) · Student t · Chi-square · F**

---

## Quick start

```bash
pip install -r requirements.txt
python disrule_app.py            # opens the desktop dashboard
```

The dashboard (Tkinter, no server needed) has three tabs:

| Tab | What you set |
| --- | --- |
| **Distribution** | distribution, probability warp (logit / linear), P display range, value range, custom title |
| **Lines & df** | value lines per half (1–3), the df value of every line, highlight + grid toggles, front/back swap |
| **Sheet & ticks** | units (mm/in), half width, sheet length, margin, tick-engine parameters, PNG dpi |

Any change redraws the preview instantly. **Export PDF + SVG + PNG ...**
writes all three files.

Headless / scripting:

```bash
python disrule_app.py --dist t --df 7,14,28,35 --out my_t_rule
python disrule_app.py --dist chi2 --df 3,7,15,30 --vmax 40 --out chi_rule
python disrule_app.py --dist normal --half-width 2 --length 11 --unit in --out zrule
python disrule_app.py --dist f --df 2,8,4,12,8,20,12,30 --out frule
```

Run `python disrule_app.py --help` for every option.

---

## The fold

The PDF page is the **whole sheet**: `length x (2 x half width)`
(e.g. 280 x 100 mm). It contains two scale halves separated by a dashed
fold line:

```
+----------------------------------------------+
| FRONT :  P line + value line(s)   (upright)  |
| - - - - - - - - - fold - - - - - - - - - - - |
| BACK  :  P line + value line(s)   (rotated)  |
+----------------------------------------------+
```

1. Print at **100% scale** (no "fit to page" — that would distort the mm).
2. Fold the BACK half **behind** the FRONT half along the dashed line.
3. You get a `length x half width` double-sided ruler. The back face is
   pre-rotated 180°, so it reads upright after folding.

Every half carries **its own P line**, aligned vertically with its value
lines: find the value, read the probability directly below/above it.

### How each rule uses the two halves

| Distribution | FRONT half | BACK half |
| --- | --- | --- |
| Normal (z) | `z >= 0` with `P = Phi(z)` in [0.5, Pmax] | `z <= 0` with `P` in [Pmin, 0.5] |
| t-Student | P + df1 + df2, full range | P + df3 + df4, full range |
| Chi-square | P (right tail) + df1 + df2 | P + df3 + df4 |
| F | P (right tail) + F(d1,d2) + F(d3,d4) | P + F(d5,d6) + F(d7,d8) |

Chi-square and F use **right-tail probabilities** (`P = 1 - CDF`), so their
P line reads 0.999 ... 0.001 — large statistics on the left, small p-values
on the right, exactly like chi-square/F tables.

### The df split system

For t / chi2 / F you choose **how many value lines each half gets** (1–3).
The first N lines go to the FRONT, the remaining N go to the BACK — the
dashboard labels every df field explicitly ("FRONT line 1", "BACK line 1",
...), so you decide which df lives on which side simply by where you type
it. The **Swap front <-> back** button exchanges the two sets.

- t / chi2: each line needs **1 df** (2 x lines numbers total)
- F: each line needs **(d1, d2)** (4 x lines numbers total)

---

## The dynamic tick engine

Every line is placed by a monotone mapping `value -> position`, so the
engine is completely distribution-agnostic. Its rules (all thresholds are
physical, in mm/points, hence print-true at any sheet size):

- **Labeled ticks** use "nice" steps (1 / 2 / 2.5 / 5 x 10^k) chosen
  *locally*: where the mapping stretches, steps refine (more marks); where
  it compresses, steps coarsen. Every label is guaranteed clearance equal
  to its own text width or the minimum label gap, whichever is larger.
- **Minor (unmarked) ticks** target **10 between neighbouring labeled
  ticks** (configurable 2–20). Where the mapping is compressed the count is
  reduced automatically so minors never crowd; blank regions first receive
  *more labeled ticks* instead.
- **Key values are highlighted**: alpha-relevant probabilities
  (0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.9, 0.95, 0.975, 0.99, 0.995,
  0.999), integers on z/t lines, x5 values on chi2, 0.5 steps on F get a
  heavier tick and a bold label.
- A faint **alignment grid** connects the P line with the value lines at
  every P major tick (toggleable).

Engine knobs (Sheet & ticks tab / CLI): `minors per major`, `min label gap
(mm)`, `min minor gap (mm)`.

### Warp: why the P axis is usually logit

On a linear probability axis the tails (where hypothesis testing lives)
collapse. The **logit** warp (`position ~ log(p/(1-p))`) re-expands both
tails so that 0.95 / 0.975 / 0.99 / 0.999 stay readable — the same idea as
the original t DisRule. Choose **linear** to reproduce the classic
evenly-spaced P behaviour (the tick engine then simply thins the crowded
tail for you). The warp is a dropdown; both are always available.

Note the coupling between ranges: a value is only drawn where its
probability lies inside the P display range. E.g. for the normal rule with
Pmax = 0.999 the z axis ends at 3.09; raise Pmax to 0.99997 to show z up to
4. The status bar shows what was built, and lines whose range does not
intersect the P range are skipped with a note.

---

## Files

```
disrule_app.py           entry point (GUI + CLI)
disrule/
  distributions.py       normal / t / chi2 / F specs, tails, priorities
  distmath.py            pure-Python cdf/sf/ppf for all four distributions
                         (no numpy/scipy needed)
  tick_engine.py         the dynamic adaptive tick engine
  layout.py              config, validation, sheet geometry, df split
  render.py              PDF (reportlab) / SVG / PNG + preview (Pillow)
  fonts/                 bundled DejaVu fonts for identical PNGs everywhere
samples/                 ready-made examples (all four distributions)
requirements.txt         just reportlab + Pillow (~15 MB installed)
```

All statistics are computed by the built-in `distmath` module (regularized
incomplete beta/gamma functions + bracketed Newton quantiles), validated
against scipy to 1e-12. That keeps the installation tiny: no numpy, no
scipy, no matplotlib.

## Tips

- **Paper**: the A4-friendly default (280 x 100 mm sheet -> 280 x 50 mm
  ruler) prints 1:1 on A4 portrait. For the classic 4 x 12 in sheet set
  units to inches, half width 2, length 12 and print with "fit to page".
- **Stiffness**: print on cardstock (160-250 g/m2), or glue the folded
  rule onto a strip of cardboard.
- **Cutting**: the hairline frame is the cut line; the dashed line is the
  fold (print side out, fold the BACK half behind).
- **More precision in the tails**: raise Pmax (e.g. 0.9999) and lower Pmin.
- **Non-integer dfs** are allowed (e.g. 7.5) - the built-in engine handles them.

## Sample output (samples/)

- `normal_z.*` - +/-z split rule, logit P axis
- `t_student_df7_14_28_35.*` - the classic 4-df t rule
- `chi2_df3_7_15_30.*` - chi-square, right-tail P
- `f_df2-8_4-12_8-20_12-30.*` - F rule with (d1, d2) pairs
- `chi2_1line_per_half.*` - 1 line per half variant
- `stress_t_3lines_linear_small.*` - 3 lines/half on a tiny 160 x 76 mm
  sheet, linear warp (the engine shrinks fonts and thins ticks to fit)
