#!/bin/bash
# ============================================================
#  DisRule - launcher for Linux
#  Run:  bash run_linux.sh
#  Needs python3 + tkinter:  sudo apt install python3 python3-tk
#  Libraries (~15 MB) go inside Python, not in this folder.
# ============================================================
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 is not installed. On Debian/Ubuntu run:"
    echo "  sudo apt install python3 python3-tk python3-venv"
    exit 1
fi

if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "The tkinter module is missing. On Debian/Ubuntu run:"
    echo "  sudo apt install python3-tk"
    exit 1
fi

# already satisfied?
if python3 -c "import reportlab, PIL" >/dev/null 2>&1; then
    exec python3 disrule_app.py
fi

echo "One-time setup - downloading 2 small helper libraries (~15 MB)..."
if python3 -m pip install --disable-pip-version-check -r requirements.txt; then
    exec python3 disrule_app.py
fi

# pip blocked (PEP 668 externally-managed environment) -> local .venv fallback
echo ""
echo "Direct install was blocked - using a local setup folder instead."
python3 -m venv .venv || { echo "Setup failed - install python3-venv."; exit 1; }
.venv/bin/pip install --quiet --disable-pip-version-check -r requirements.txt \
    || { echo "Download failed - check internet, then try again."; exit 1; }
exec .venv/bin/python disrule_app.py
