"""Sheet layout for DisRule.

The printable sheet is a rectangle of ``length x (2 x half width)``.
Two scale halves sit side by side across the fold line:

  - FRONT half  (top strip on the sheet):  its own P line + value line(s)
  - BACK  half  (bottom strip):            its own P line + value line(s),
                                            printed rotated 180 degrees

Folding the back half behind the front half (mountain fold, printed side
out) yields a double-sided ruler of ``length x half width`` in which every
face reads upright and carries its own P line.

The layout engine produces a backend-neutral list of primitives
(lines / texts) which render.py turns into PDF, SVG or PNG.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .distributions import DISTRIBUTIONS, P_PRIORITIES
from .tick_engine import build_scale, estimate_label_pt

PT_PER_MM = 72.0 / 25.4
MM_PER_PT = 25.4 / 72.0

# Okabe-Ito palette (colour-blind safe, prints well)
PALETTE = ["#D55E00", "#0072B2", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"]
P_COLOR = "#111111"
GRID_COLOR = "#cccccc"
FRAME_COLOR = "#9a9a9a"
TITLE_COLOR = "#333333"
TAG_COLOR_LUM = "#555555"
FOLD_COLOR = "#8a8a8a"


# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------

@dataclass
class RulerConfig:
    dist_key: str = "t"
    warp: str = "logit"            # "logit" | "linear"
    p_min: float = 0.001
    p_max: float = 0.999
    v_min: float = -5.0
    v_max: float = 5.0
    lines_per_half: int = 2        # value lines per half (normal forces 1)
    dfs: tuple = ()                # t/chi2: (d1..d2n)  F: flat (d1,d2,...)
    half_width_mm: float = 50.0
    length_mm: float = 280.0
    margin_mm: float = 8.0
    minors_per_major: int = 10
    min_label_gap_mm: float = 3.2
    min_minor_gap_mm: float = 0.9
    show_grid: bool = True
    highlight: bool = True
    title: str = ""
    dpi: int = 200


def validate(cfg):
    """Return a list of error strings (empty when the config is usable)."""
    errs = []
    if cfg.dist_key not in DISTRIBUTIONS:
        errs.append(f"unknown distribution '{cfg.dist_key}'")
        return errs
    spec = DISTRIBUTIONS[cfg.dist_key]
    n = 1 if spec.key == "normal" else cfg.lines_per_half
    if not (1 <= n <= 3):
        errs.append("value lines per half must be 1..3")
    if not (1e-5 <= cfg.p_min < cfg.p_max <= 1 - 1e-5):
        errs.append("P range must satisfy 0.00001 <= Pmin < Pmax <= 0.99999")
    if not (cfg.v_min < cfg.v_max):
        errs.append("value range: vmin must be < vmax")
    if not (18.0 <= cfg.half_width_mm <= 250.0):
        errs.append("half width must be 18..250 mm")
    if not (40.0 <= cfg.length_mm <= 2000.0):
        errs.append("length must be 40..2000 mm")
    if not (1.0 <= cfg.margin_mm <= cfg.length_mm / 3.0):
        errs.append("margin must be 1 mm .. length/3")
    if cfg.warp not in ("logit", "linear"):
        errs.append("warp must be 'logit' or 'linear'")
    need = 0 if spec.key == "normal" else (4 * n if spec.key == "f" else 2 * n)
    if len(cfg.dfs) != need:
        errs.append(f"this rule needs {need} df numbers "
                    f"({n} front + {n} back lines), got {len(cfg.dfs)}")
    else:
        for d in cfg.dfs:
            if not (math.isfinite(d) and d > 0):
                errs.append("all degrees of freedom must be positive numbers")
                break
    if not (2 <= cfg.minors_per_major <= 20):
        errs.append("minors per major must be 2..20")
    if not (1.5 <= cfg.min_label_gap_mm <= 15.0):
        errs.append("min label gap must be 1.5..15 mm")
    if not (0.4 <= cfg.min_minor_gap_mm <= 5.0):
        errs.append("min minor gap must be 0.4..5 mm")
    return errs


# --------------------------------------------------------------------------
# primitives
# --------------------------------------------------------------------------

@dataclass
class PrimLine:
    x1: float
    y1: float
    x2: float
    y2: float
    w: float = 1.0
    color: str = "#000000"
    dash: tuple = ()


@dataclass
class PrimText:
    x: float
    y: float          # vertical CENTER of the text
    s: str
    size: float
    color: str = "#000000"
    bold: bool = False
    rot: float = 0.0  # degrees, sheet coords


@dataclass
class Sheet:
    width_pt: float
    height_pt: float
    width_mm: float
    height_mm: float
    prims: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)


# --------------------------------------------------------------------------
# per-half plans
# --------------------------------------------------------------------------

@dataclass
class _Plan:
    kind: str            # "p" | "value"
    dfs: tuple
    domain: tuple        # (lo, hi) in the plan's own variable (p or value)
    pos: object          # value -> local x (pts), used by the tick engine
    priorities: tuple


def _half_p_domain(spec, cfg, which):
    """P range shown on one half's own P line.

    The normal rule is inherently +/- split: the front half carries the
    positive z side (P = CDF in [0.5, Pmax]) and the back half the negative
    side (P in [Pmin, 0.5]).  Every other rule shows the full P range on
    both halves.
    """
    if spec.key == "normal":
        if which == "front":
            return max(cfg.p_min, 0.5), cfg.p_max
        return cfg.p_min, min(cfg.p_max, 0.5)
    return cfg.p_min, cfg.p_max


def _make_warp01_domain(cfg, p_lo, p_hi):
    """Warp normalised over THIS half's P domain (axis spans full width)."""
    if cfg.warp == "linear":
        return lambda p: (p - p_lo) / (p_hi - p_lo)

    def _logit(p):
        p = min(max(p, 1e-12), 1 - 1e-12)
        return math.log(p / (1.0 - p))

    lmin, lmax = _logit(p_lo), _logit(p_hi)
    return lambda p: (_logit(p) - lmin) / (lmax - lmin)


def _clip_domain(spec, cfg, dfs, p_lo, p_hi):
    """Intersect the user value range with this half's P display range."""
    lo_p = spec.value_of_p(p_lo, dfs)
    hi_p = spec.value_of_p(p_hi, dfs)
    dlo, dhi = (lo_p, hi_p) if lo_p <= hi_p else (hi_p, lo_p)
    lo = max(cfg.v_min, dlo)
    hi = min(cfg.v_max, dhi)
    return lo, hi


def _make_pos(kind, spec, cfg, dfs, warp_half, margin, W):
    right = spec.tail == "right"
    if kind == "p":
        if right:
            return lambda q: margin + W * (1.0 - warp_half(q))
        return lambda q: margin + W * warp_half(q)
    if right:
        return lambda v: margin + W * (1.0 - warp_half(spec.p_of_value(v, dfs)))
    return lambda v: margin + W * warp_half(spec.p_of_value(v, dfs))


def _build_plans(which, spec, cfg, dfs_list, margin, W, notes):
    """which: "front" | "back".  Returns list of _Plan: [P, value lines].
    All lines of the half share one warp so values stay aligned with P."""
    plans = []
    p_lo, p_hi = _half_p_domain(spec, cfg, which)
    warp_half = _make_warp01_domain(cfg, p_lo, p_hi)
    # ---- P line plan ----------------------------------------------------
    pos_p = _make_pos("p", spec, cfg, (), warp_half, margin, W)
    plans.append(_Plan("p", (), (p_lo, p_hi), pos_p, tuple(P_PRIORITIES)))
    # ---- value line plans -----------------------------------------------
    for dfs in dfs_list:
        lo, hi = _clip_domain(spec, cfg, dfs, p_lo, p_hi)
        if not (hi > lo):
            notes.append(f"line {spec.df_tag(dfs)} ({which}): value range "
                         f"does not intersect this half's P range - skipped")
            continue
        pos_v = _make_pos("value", spec, cfg, dfs, warp_half, margin, W)
        pri = tuple(spec.value_priorities(lo, hi))
        plans.append(_Plan("value", tuple(dfs), (lo, hi), pos_v, pri))
    return plans


# --------------------------------------------------------------------------
# half geometry
# --------------------------------------------------------------------------

def _fit_geometry(k, H_pt):
    """Fit (font, tick, gap_P, gap_V) for k value lines into a half strip."""
    title_band = 4.8 * PT_PER_MM
    fold_pad = 1.6 * PT_PER_MM
    avail = H_pt - title_band - fold_pad
    font, tick, gap = 8.0, 14.0, 5.0
    for _ in range(12):
        needed = (1.55 * font + tick + gap            # P labels + P tick
                  + k * (tick + 1.9 * font)           # value tick + labels
                  + max(0, k - 1) * gap + gap)        # inter-line + fold gap
        if needed <= avail:
            break
        s = max(0.86, avail / needed)
        font = max(4.4, font * s)
        tick = max(5.0, tick * s)
        gap = max(2.0, gap * s)
    # distribute leftover space into the gaps
    fixed = (1.55 * font + tick + k * (tick + 1.9 * font))
    leftover = max(0.0, avail - fixed)
    gap_v = leftover / (k + 1) if k >= 1 else leftover
    gap_v = min(gap_v, 14.0)
    gap_p = max(2.0, leftover - gap_v * k if k >= 1 else leftover * 0.5)
    return font, tick, max(2.0, gap_p), gap_v


def _build_half_prims(plans, spec, cfg, H_pt, L_pt, margin, W, which,
                      color_offset, fallback_tag, stats_out, notes):
    """Render one half in its LOCAL frame: x in [0, L], y = 0 at the fold,
    y = H at the outer edge.  Returns (prims, font, tick, y_P, y_vals)."""
    k = len(plans) - 1
    font, tick, gap_p, gap_v = _fit_geometry(k, H_pt)
    font = round(font, 2)
    tick = round(tick, 2)
    minor_len = max(2.5, 0.38 * tick)
    mid_len = max(3.5, 0.60 * tick)

    y_P = H_pt - 4.8 * PT_PER_MM - 1.55 * font - tick
    y_vals = []
    y = y_P - gap_p
    for _j in range(k):
        y -= tick
        y_vals.append(y)
        y -= 1.9 * font + gap_v

    if y_vals and y_vals[-1] - tick - 1.9 * font < 1.2 * PT_PER_MM:
        notes.append("half is very cramped for this many lines - consider a "
                     "wider half width or fewer lines")

    prims = []

    # ---- per-line tick/label drawing ------------------------------------
    for idx, plan in enumerate(plans):
        y_base = y_P if plan.kind == "p" else y_vals[idx - 1]
        if plan.kind == "p":
            color = P_COLOR
        else:
            color = PALETTE[(color_offset + idx - 1) % len(PALETTE)]
        font_here = font
        labeled, minors, st = build_scale(
            plan.pos, plan.domain[0], plan.domain[1],
            min_label_gap_pt=cfg.min_label_gap_mm * PT_PER_MM,
            min_minor_gap_pt=cfg.min_minor_gap_mm * PT_PER_MM,
            minors_target=cfg.minors_per_major,
            font_pt=font_here,
            priorities=plan.priorities if cfg.highlight else ())
        tag = "P" if plan.kind == "p" else (spec.df_tag(plan.dfs)
                                            or fallback_tag)
        stats_out[f"{tag} ({which})"] = st

        up = plan.kind == "p"          # P ticks point to the outer edge
        sgn = 1 if up else -1

        # baseline
        prims.append(PrimLine(margin, y_base, margin + W, y_base,
                              w=1.3, color=color))
        # ticks + labels
        for t in labeled:
            pri = t.kind == "priority"
            ln = tick * (1.18 if pri else 1.0)
            prims.append(PrimLine(t.x, y_base, t.x, y_base + sgn * ln,
                                  w=1.5 if pri else 1.1, color=color))
            if not t.label:
                continue  # unlabeled end tick (domain anchor)
            fs = font_here * (1.12 if pri else 1.0)
            if up:
                y_c = y_base + ln + 0.85 * fs
            else:
                y_c = y_base - ln - 0.95 * fs
            prims.append(PrimText(t.x, y_c, t.label, fs,
                                  color=color, bold=pri))
        for t in minors:
            ln = mid_len if t.kind == "minor_mid" else minor_len
            prims.append(PrimLine(t.x, y_base, t.x, y_base + sgn * ln,
                                  w=0.8 if t.kind == "minor_mid" else 0.5,
                                  color=color))

        # line tag (left end, above the baseline for value lines)
        if plan.kind == "value" and tag:
            tw = estimate_label_pt(tag, font_here * 0.85)
            prims.append(PrimText(margin + tw / 2 + 4,
                                  y_base + 1.05 * font_here,
                                  tag, font_here * 0.85, color=color,
                                  bold=True))

    return prims, font, tick, y_P, y_vals


def build_sheet(cfg: RulerConfig) -> Sheet:
    errs = validate(cfg)
    if errs:
        raise ValueError("; ".join(errs))

    spec = DISTRIBUTIONS[cfg.dist_key]
    n = 1 if spec.key == "normal" else cfg.lines_per_half
    notes = []

    L = cfg.length_mm * PT_PER_MM
    H = cfg.half_width_mm * PT_PER_MM
    margin = cfg.margin_mm * PT_PER_MM
    W = L - 2 * margin

    # ---- df split: first n lines -> front, last n -> back ----------------
    if spec.key == "normal":
        dfs_front, dfs_back = [()], [()]
    elif spec.key == "f":
        pairs = [tuple(cfg.dfs[2 * i:2 * i + 2]) for i in range(2 * n)]
        dfs_front, dfs_back = pairs[:n], pairs[n:]
    else:
        dfs_front = [tuple(cfg.dfs[i:i + 1]) for i in range(n)]
        dfs_back = [tuple(cfg.dfs[n + i:n + i + 1]) for i in range(n)]

    stats_out = {}

    def make_half(which):
        dfs_list = dfs_front if which == "front" else dfs_back
        color_offset = 0 if which == "front" else n
        fb_tag = ("+z" if which == "front" else "-z") \
            if spec.key == "normal" else ""
        plans = _build_plans(which, spec, cfg, dfs_list,
                             margin, W, notes)
        prims, font, tick, y_P, y_vals = _build_half_prims(
            plans, spec, cfg, H, L, margin, W, which, color_offset,
            fb_tag, stats_out, notes)
        return prims, plans, font, tick, y_P, y_vals

    front_prims, front_plans, font, tick, y_P, y_vals = make_half("front")
    back_prims, back_plans, _, _, _, _ = make_half("back")

    # ---- assemble sheet with transforms ----------------------------------
    # FRONT: local (x, y) -> sheet (x, H - y)          [top strip]
    # BACK : local (x, y) -> sheet (L - x, H + y)      [bottom strip, 180 deg]
    prims = []
    for p in front_prims:
        if isinstance(p, PrimLine):
            prims.append(PrimLine(p.x1, H - p.y1, p.x2, H - p.y2,
                                  p.w, p.color, p.dash))
        else:
            prims.append(PrimText(p.x, H - p.y, p.s, p.size, p.color,
                                  p.bold, 0.0))
    for p in back_prims:
        if isinstance(p, PrimLine):
            prims.append(PrimLine(L - p.x1, H + p.y1, L - p.x2, H + p.y2,
                                  p.w, p.color, p.dash))
        else:
            prims.append(PrimText(L - p.x, H + p.y, p.s, p.size, p.color,
                                  p.bold, 180.0))

    # ---- alignment grid at P-line labeled ticks ---------------------------
    if cfg.show_grid:
        y_top = y_P - 0.5
        y_bot = (y_vals[-1] if y_vals else y_P)
        for plan in front_plans:
            if plan.kind != "p":
                continue
            labeled, _m, _s = build_scale(
                plan.pos, plan.domain[0], plan.domain[1],
                min_label_gap_pt=cfg.min_label_gap_mm * PT_PER_MM,
                min_minor_gap_pt=cfg.min_minor_gap_mm * PT_PER_MM,
                minors_target=cfg.minors_per_major,
                font_pt=font,
                priorities=plan.priorities)
            for t in labeled:
                prims.append(PrimLine(t.x, H - y_top, t.x, H - y_bot,
                                      w=0.4, color=GRID_COLOR,
                                      dash=(1.6, 2.2)))

    # ---- titles ------------------------------------------------------------
    # front title lives in the top margin band of the FRONT half; a rotated
    # copy sits in the bottom band so the BACK face carries it too.
    front_tags = [spec.df_tag(d) for d in dfs_front]
    back_tags = [spec.df_tag(d) for d in dfs_back]
    title = cfg.title.strip() or spec.auto_title(front_tags, back_tags)
    title = title[:110]
    tsize = min(7.0, font * 0.95)
    max_w = L - 2 * margin - 30
    tw = estimate_label_pt(title, tsize)
    if tw > max_w:
        tsize *= max_w / tw
    prims.append(PrimText(L / 2, 2.4 * PT_PER_MM, title, tsize,
                          color=TITLE_COLOR))
    prims.append(PrimText(L / 2, 2 * H - 2.4 * PT_PER_MM, title, tsize,
                          color=TITLE_COLOR, rot=180.0))

    # ---- fold line, frame, assembly hints ----------------------------------
    prims.append(PrimLine(0, H, L, H, w=1.0, color=FOLD_COLOR,
                          dash=(4, 2.4)))
    prims.append(PrimText(L - margin * 0.45, H - 3.0, "FOLD",
                          5.0, color=FOLD_COLOR))
    inset = 0.6 * PT_PER_MM
    prims.append(PrimLine(inset, inset, L - inset, inset, w=0.4,
                          color=FRAME_COLOR))
    prims.append(PrimLine(inset, 2 * H - inset, L - inset, 2 * H - inset,
                          w=0.4, color=FRAME_COLOR))
    prims.append(PrimLine(inset, inset, inset, 2 * H - inset, w=0.4,
                          color=FRAME_COLOR))
    prims.append(PrimLine(L - inset, inset, L - inset, 2 * H - inset,
                          w=0.4, color=FRAME_COLOR))
    prims.append(PrimText(L - margin * 0.45, 2.4 * PT_PER_MM, "FRONT",
                          5.0, color="#999999"))
    prims.append(PrimText(margin * 0.45, 2 * H - 2.4 * PT_PER_MM, "BACK",
                          5.0, color="#999999", rot=180.0))

    total_labels = sum(s["n_labels"] for s in stats_out.values())
    total_minors = sum(s["n_minors"] for s in stats_out.values())
    min_gap = min((s["min_label_gap_pt"] for s in stats_out.values()),
                  default=0.0)

    sheet = Sheet(width_pt=L, height_pt=2 * H,
                  width_mm=cfg.length_mm, height_mm=2 * cfg.half_width_mm,
                  prims=prims, stats=stats_out, notes=notes)
    sheet.stats["_totals"] = {
        "labels": total_labels, "minors": total_minors,
        "min_label_gap_mm": min_gap * MM_PER_PT,
    }
    return sheet
