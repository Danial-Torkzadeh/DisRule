"""Dynamic adaptive tick engine for DisRule.

Spec (from the DisRule design notes):

- Target: about 10 unmarked (minor) ticks between neighbouring marked
  (labeled) ticks.
- Where the mapping is compressed ("too many ticks per inch") the tick
  count shrinks automatically.
- Where the scale is blank ("no ticks") the engine first inserts MORE
  labeled ticks by refining to finer "nice" steps (1 / 2 / 2.5 / 5 x 10^k),
  then fills what is left with minor ticks.
- All density thresholds are physical (points), so results stay print-true
  for any sheet size, distribution, warp or degrees of freedom.

The engine only asks for one thing: a monotone position function
``pos(value) -> points``.  That makes it distribution-agnostic.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

MANTISSAS = (1.0, 2.0, 2.5, 5.0)
EPS = 1e-9


@dataclass
class Tick:
    value: float
    x: float                    # points along the line, always left -> right
    kind: str = "major"         # major | priority | minor | minor_mid
    label: str | None = None
    step: float = 0.0


# --------------------------------------------------------------------------
# nice numbers
# --------------------------------------------------------------------------

def nice_steps(span, floor):
    """All 'nice' step sizes >= floor that could tile a span this big."""
    steps = []
    k0 = math.floor(math.log10(span)) - 6
    k1 = math.ceil(math.log10(span)) + 2
    for k in range(k0, k1 + 1):
        for m in MANTISSAS:
            s = m * 10.0 ** k
            if s >= floor * (1 - 1e-12):
                steps.append(round(s, 12))
    return sorted(set(steps))


def decimals_for(step):
    for d in range(0, 7):
        if abs(round(step, d) - step) <= 1e-12 * max(1.0, step):
            return d
    return 6


def fmt_value(v, step):
    """Format v with exactly as many decimals as its step needs."""
    d = decimals_for(step) if step > 0 else 2
    s = f"{round(v, d):.{d}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s


def snap_label(v, span):
    """Short honest label for a domain endpoint (e.g. ppf-derived ends)."""
    for d in range(0, 4):
        r = round(v, d)
        tol = min(1e-3 * span, 0.05 * abs(v) + 1e-4)
        if abs(r - v) <= tol:
            return fmt_value(r, 10.0 ** (-d))
    return f"{v:.4g}"


def estimate_label_pt(s, font_pt):
    """Conservative Helvetica text width estimate in points."""
    return 0.62 * font_pt * max(1, len(s))


def _next_mult_above(step, v):
    k = math.floor(v / step + 1e-9) + 1
    x = round(k * step, 10)
    return 0.0 if abs(x) < step * 1e-9 else x


# --------------------------------------------------------------------------
# labeled ticks (adaptive nice steps)
# --------------------------------------------------------------------------

def _build_labeled_increasing(pos, lo, hi, *, min_gap_pt, font_pt,
                              priorities=(), headroom=1.55):
    a, b = pos(lo), pos(hi)
    span = hi - lo
    width = b - a
    floor = span * (min_gap_pt / width) * 0.30
    steps = nice_steps(span, floor)
    pri = sorted(p for p in priorities if lo < p < hi)

    def req(v, s):
        return max(min_gap_pt,
                   estimate_label_pt(fmt_value(v, s), font_pt) + 0.10 * font_pt)

    def label_step_for(v):
        # coarsest ladder step that divides v -> its "natural" step
        for s in reversed(steps):
            r = v / s
            if abs(r - round(r)) < 1e-6:
                return s
        return None

    # starting step: finest step whose FIRST global multiple above lo fits
    i = 0
    while i < len(steps) - 1:
        v1 = _next_mult_above(steps[i], lo)
        if v1 < hi and pos(v1) - a >= req(v1, steps[i]):
            break
        i += 1

    out = [Tick(lo, a, "priority", snap_label(lo, span), steps[i])]
    v_last, x_last, cur = lo, a, i
    guard = 0
    while guard < 5000:
        guard += 1
        v_next = _next_mult_above(steps[cur], v_last)
        if v_next >= hi - EPS * span:
            # end zone: try to squeeze finer ticks in before the end
            j = cur
            placed = False
            while j > 0:
                v_f = _next_mult_above(steps[j - 1], v_last)
                if (v_f < hi - EPS * span
                        and pos(v_f) - x_last >= req(v_f, steps[j - 1])):
                    j -= 1
                    placed = True
                else:
                    break
            if not placed:
                break
            cur = j
            v_next = _next_mult_above(steps[cur], v_last)
        else:
            # escalate to coarser steps while the candidate is too tight
            while (cur + 1 < len(steps)
                   and pos(v_next) - x_last < req(v_next, steps[cur])):
                cur += 1
                v_next = _next_mult_above(steps[cur], v_last)
            if v_next >= hi - EPS * span:
                continue            # end zone - handled next iteration
            # refine to finer steps while one clearly fits (hysteresis)
            while cur > 0:
                v_f = _next_mult_above(steps[cur - 1], v_last)
                if (v_f < hi - EPS * span and pos(v_f) - x_last
                        >= headroom * req(v_f, steps[cur - 1])):
                    cur -= 1
                    v_next = v_f
                else:
                    break
        x_next = pos(v_next)
        if x_next >= b - 0.01:
            break
        is_pri = any(abs(v_next - p) <= steps[cur] * 1e-6 for p in pri)
        out.append(Tick(v_next, x_next,
                        "priority" if is_pri else "major",
                        snap_label(v_next, span) if is_pri
                        else fmt_value(v_next, steps[cur]),
                        steps[cur]))
        v_last, x_last = v_next, x_next

    # force endpoint + priority values (regulars that collide give way)
    forced = pri + [hi]
    for f in forced:
        xf = pos(f)
        s_f = label_step_for(f)
        lab = fmt_value(f, s_f) if s_f else snap_label(f, span)
        rf = max(min_gap_pt, estimate_label_pt(lab, font_pt) + 0.10 * font_pt)
        clash = next((t for t in out if abs(t.x - xf) < 1.5), None)
        if clash is not None:
            if not clash.label:
                out.remove(clash)   # an unlabeled tick gives way to a label
            else:
                continue            # already labeled there
        # conflict with an existing priority tick: the "nicer" value keeps
        # its label, the loser stays as an unlabeled anchor tick.
        pri_conf = [t for t in out if t.kind == "priority"
                    and abs(t.x - xf) < rf * 0.98]
        if pri_conf:
            t = pri_conf[0]
            t_step = t.step if t.step > 0 else span * 10.0
            f_step = s_f if s_f else span * 10.0
            if t_step <= f_step * 1.0001:
                out.append(Tick(f, xf, "major", None, 0.0))
                continue
            out = [Tick(x.value, x.x, "major", None, 0.0) if x is t else x
                   for x in out]
        keep = []
        for t in out:
            r_t = max(min_gap_pt, estimate_label_pt(t.label or "", font_pt)
                      + 0.10 * font_pt) if t.label else min_gap_pt
            if t.kind == "major" and t.label \
                    and abs(t.x - xf) < max(rf, r_t) * 0.98:
                continue  # drop the regular, the priority takes the spot
            keep.append(t)
        keep.append(Tick(f, xf, "priority", lab, s_f or 0.0))
        out = keep

    out.sort(key=lambda t: t.x)

    # ---- final safety pass: enforce labeled-tick clearance ----------------
    # Whatever path produced the ticks, no two LABELS may end up closer
    # than their required clearance; the weaker (finer-step or later) one
    # is demoted to an unlabeled anchor tick.
    def _req_of(t):
        if not t.label:
            return min_gap_pt
        return max(min_gap_pt,
                   estimate_label_pt(t.label, font_pt) + 0.10 * font_pt)

    changed = True
    while changed:
        changed = False
        out.sort(key=lambda t: t.x)
        for i, t in enumerate(out):
            if not t.label:
                continue
            rt = _req_of(t)
            hit = None
            for j in (i - 1, i + 1):
                if 0 <= j < len(out) and out[j].label:
                    if abs(out[j].x - t.x) < min(rt, _req_of(out[j])) * 0.95:
                        hit = j
                        break
            if hit is None:
                continue
            o = out[hit]
            s_t = t.step if t.step > 0 else 1e18
            s_o = o.step if o.step > 0 else 1e18
            # keep the nicer (coarser natural step); tie -> keep the earlier
            loser = o if s_t <= s_o else t
            out = [x if x is not loser
                   else Tick(loser.value, loser.x, "major", None, 0.0)
                   for x in out]
            changed = True
            break

    # ---- drop unlabeled ticks that crowd a neighbouring tick --------------
    kept = []
    for t in out:
        if t.label or not kept or abs(t.x - kept[-1].x) >= 3.5:
            kept.append(t)
    kept2 = []
    for t in reversed(kept):                     # same, against successors
        if t.label or not kept2 or abs(t.x - kept2[-1].x) >= 3.5:
            kept2.append(t)
    kept2.reverse()
    out = kept2

    res = [out[0]]
    for t in out[1:]:
        if t.x - res[-1].x < 1.0 and t.kind == "major":
            continue
        if t.x - res[-1].x < 0.5:
            continue
        res.append(t)
    return res


# --------------------------------------------------------------------------
# minor (unmarked) ticks
# --------------------------------------------------------------------------

def _build_minors(pos, labeled, target, min_minor_gap_pt):
    minors = []
    for t1, t2 in zip(labeled, labeled[1:]):
        v1, v2, x1, x2 = t1.value, t2.value, t1.x, t2.x
        n = int(target)
        vs, xs = [], []
        fit = False
        while n >= 1:
            vs = [v1 + (v2 - v1) * k / (n + 1) for k in range(1, n + 1)]
            xs = [pos(v) for v in vs]
            allx = [x1] + xs + [x2]
            if min(b - a for a, b in zip(allx, allx[1:])) >= min_minor_gap_pt:
                fit = True
                break
            n -= 1
        if not fit:
            continue  # too tight even for one minor - leave it blank
        for k, (v, x) in enumerate(zip(vs, xs), start=1):
            kind = "minor_mid" if (n >= 4 and k == (n + 1) // 2) else "minor"
            minors.append(Tick(v, x, kind))
    return minors


# --------------------------------------------------------------------------
# public entry point
# --------------------------------------------------------------------------

def build_scale(pos, lo, hi, *, min_label_gap_pt, min_minor_gap_pt,
                minors_target=10, font_pt=8.0, priorities=()):
    """Build labeled + minor ticks for one line.

    ``pos`` may be increasing or decreasing in ``value``; ticks are always
    returned with x increasing left -> right.
    """
    if not (hi > lo):
        raise ValueError(f"empty domain: [{lo}, {hi}]")

    increasing = pos(lo) <= pos(hi)
    if increasing:
        labeled = _build_labeled_increasing(
            pos, lo, hi, min_gap_pt=min_label_gap_pt, font_pt=font_pt,
            priorities=priorities)
        minors = _build_minors(pos, labeled, minors_target, min_minor_gap_pt)
    else:
        wrapped = lambda v: -pos(v)  # noqa: E731
        labeled = _build_labeled_increasing(
            wrapped, lo, hi, min_gap_pt=min_label_gap_pt, font_pt=font_pt,
            priorities=priorities)
        minors = _build_minors(wrapped, labeled, minors_target,
                               min_minor_gap_pt)
        for t in labeled:
            t.x = -t.x
        for t in minors:
            t.x = -t.x
        labeled.sort(key=lambda t: t.x)
        minors.sort(key=lambda t: t.x)

    gaps = [t2.x - t1.x for t1, t2 in zip(labeled, labeled[1:])]
    mgaps = [t2.x - t1.x for t1, t2 in zip(minors, minors[1:])]
    stats = {
        "n_labels": len(labeled),
        "n_minors": len(minors),
        "min_label_gap_pt": min(gaps) if gaps else 0.0,
        "min_minor_gap_pt": min(mgaps) if mgaps else 0.0,
    }
    return labeled, minors, stats
