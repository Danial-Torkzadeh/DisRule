"""Rendering backends for DisRule sheets.

The layout engine emits backend-neutral primitives; this module turns them
into a print-ready PDF (reportlab), a vector SVG, a PNG image (Pillow) or
raster bytes for the GUI preview.  Pure line art + text: no numpy needed.
"""
from __future__ import annotations

import io
import math
import os

from .layout import PrimLine, PrimText, PT_PER_MM

_TEXT_LATIN = lambda s: s.encode("latin-1", "replace").decode("latin-1")  # noqa: E731

_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
_FONT_CACHE = {}
_SS = 2            # supersample factor for anti-aliased raster output


def _hex(color):
    color = color.lstrip("#")
    return tuple(int(color[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


# --------------------------------------------------------------------------
# PDF (print-true, exact page size)
# --------------------------------------------------------------------------

def render_pdf(sheet, path, title="DisRule"):
    from reportlab.lib.colors import Color
    from reportlab.pdfgen import canvas as rl_canvas

    W, H = sheet.width_pt, sheet.height_pt
    c = rl_canvas.Canvas(path, pagesize=(W, H))
    c.setTitle(title[:80] or "DisRule")

    def col(hexs, alpha=1.0):
        r, g, b = _hex(hexs)
        return Color(r, g, b, alpha)

    for p in sheet.prims:
        if isinstance(p, PrimLine):
            c.saveState()
            c.setStrokeColor(col(p.color))
            c.setLineWidth(p.w)
            if p.dash:
                c.setDash(*p.dash)
            c.line(p.x1, H - p.y1, p.x2, H - p.y2)
            c.restoreState()
        elif isinstance(p, PrimText):
            c.saveState()
            c.translate(p.x, H - p.y)
            if p.rot:
                c.rotate(p.rot)
            c.setFillColor(col(p.color))
            c.setFont("Helvetica-Bold" if p.bold else "Helvetica", p.size)
            c.drawCentredString(0, -0.35 * p.size, _TEXT_LATIN(p.s))
            c.restoreState()
    c.showPage()
    c.save()


# --------------------------------------------------------------------------
# SVG (vector, editable)
# --------------------------------------------------------------------------

def _esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;"))


def render_svg(sheet, path, title="DisRule"):
    W = sheet.width_pt / PT_PER_MM
    H = sheet.height_pt / PT_PER_MM
    out = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{W:.3f}mm" height="{H:.3f}mm" '
        f'viewBox="0 0 {sheet.width_pt:.3f} {sheet.height_pt:.3f}">',
        f'<title>{_esc(title[:80] or "DisRule")}</title>',
        f'<rect x="0" y="0" width="{sheet.width_pt:.3f}" '
        f'height="{sheet.height_pt:.3f}" fill="#ffffff"/>',
    ]
    for p in sheet.prims:
        if isinstance(p, PrimLine):
            dash = (f' stroke-dasharray="{p.dash[0]},{p.dash[1]}"'
                    if p.dash else "")
            out.append(
                f'<line x1="{p.x1:.2f}" y1="{p.y1:.2f}" '
                f'x2="{p.x2:.2f}" y2="{p.y2:.2f}" '
                f'stroke="{p.color}" stroke-width="{p.w}"{dash} '
                f'stroke-linecap="butt"/>')
        elif isinstance(p, PrimText):
            bold = ' font-weight="bold"' if p.bold else ""
            rot = (f' transform="rotate({p.rot:g} {p.x:.2f} {p.y:.2f})"'
                   if p.rot else "")
            out.append(
                f'<text x="{p.x:.2f}" y="{p.y:.2f}" '
                f'font-family="Helvetica, Arial, sans-serif" '
                f'font-size="{p.size:.2f}" fill="{p.color}"{bold} '
                f'text-anchor="middle" dominant-baseline="central"{rot}>'
                f'{_esc(p.s)}</text>')
    out.append("</svg>")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(out))


# --------------------------------------------------------------------------
# Pillow raster (PNG + GUI preview)
# --------------------------------------------------------------------------

def _font(size_px, bold):
    key = (int(round(size_px)), bold)
    if key not in _FONT_CACHE:
        from PIL import ImageFont
        name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
        _FONT_CACHE[key] = ImageFont.truetype(
            os.path.join(_FONT_DIR, name), max(1, int(round(size_px))))
    return _FONT_CACHE[key]


def _dashed_line(dr, x1, y1, x2, y2, width, dash, fill):
    """Draw a dashed line segment by hand (Pillow has no dash support)."""
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy)
    if length <= 0:
        return
    ux, uy = dx / length, dy / length
    on, off = dash[0], dash[1]
    t = 0.0
    while t < length:
        t2 = min(t + on, length)
        dr.line([x1 + ux * t, y1 + uy * t, x1 + ux * t2, y1 + uy * t2],
                fill=fill, width=width)
        t += on + off


def _draw_rotated_text(img, p, s):
    """Render one PrimText (with rotation) onto img at supersample scale s."""
    from PIL import Image, ImageDraw

    fpx = max(1, p.size * s)
    font = _font(fpx, p.bold)
    measure = Image.new("RGBA", (4, 4))
    md = ImageDraw.Draw(measure)
    x0, y0, x1, y1 = md.textbbox((0, 0), p.s, font=font)
    tw, th = x1 - x0, y1 - y0
    pad = int(fpx * 0.35) + 2
    tmp = Image.new("RGBA", (int(tw) + 2 * pad, int(th) + 2 * pad), (0, 0, 0, 0))
    td = ImageDraw.Draw(tmp)
    td.text((pad - x0, pad - y0), p.s, font=font, fill=p.color)
    if p.rot:
        # sheet coords are y-down; PDF/SVG rotation is applied in that frame
        tmp = tmp.rotate(-p.rot, expand=True, resample=Image.BICUBIC)
    img.paste(tmp, (int(round(p.x * s - tmp.width / 2)),
                    int(round(p.y * s - tmp.height / 2))), tmp)


def _render_raster(sheet, scale_px_per_pt):
    """Render the sheet to a PIL RGB image at the given resolution."""
    from PIL import Image, ImageDraw

    s = scale_px_per_pt * _SS
    W = max(1, int(round(sheet.width_pt * s)))
    H = max(1, int(round(sheet.height_pt * s)))
    img = Image.new("RGB", (W, H), "white")
    dr = ImageDraw.Draw(img)
    for p in sheet.prims:
        if isinstance(p, PrimLine):
            w = max(1, int(round(p.w * s)))
            if p.dash:
                _dashed_line(dr, p.x1 * s, p.y1 * s, p.x2 * s, p.y2 * s,
                             w, (p.dash[0] * s, p.dash[1] * s), p.color)
            else:
                dr.line([p.x1 * s, p.y1 * s, p.x2 * s, p.y2 * s],
                        fill=p.color, width=w)
        elif isinstance(p, PrimText):
            _draw_rotated_text(img, p, s)
    out_w = max(1, int(round(sheet.width_pt * scale_px_per_pt)))
    out_h = max(1, int(round(sheet.height_pt * scale_px_per_pt)))
    return img.resize((out_w, out_h), Image.LANCZOS)


def render_png(sheet, path, dpi=200, title="DisRule"):
    scale = dpi / 72.0                       # px per pt
    img = _render_raster(sheet, scale)
    img.save(path, "PNG", dpi=(dpi, dpi))


def render_png_bytes(sheet, target_width_px=1400):
    """Rasterize the sheet for the GUI preview (fits given pixel width)."""
    scale = max(1.0, target_width_px / sheet.width_pt)
    img = _render_raster(sheet, scale)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


# --------------------------------------------------------------------------
# export helper
# --------------------------------------------------------------------------

def export_set(sheet, base_path, title="DisRule", dpi=200, want=("pdf", "svg", "png")):
    """Write <base>.pdf / <base>.svg / <base>.png; returns written paths."""
    import os
    parent = os.path.dirname(os.path.abspath(base_path))
    os.makedirs(parent, exist_ok=True)
    written = []
    if "pdf" in want:
        p = f"{base_path}.pdf"
        render_pdf(sheet, p, title=title)
        written.append(p)
    if "svg" in want:
        p = f"{base_path}.svg"
        render_svg(sheet, p, title=title)
        written.append(p)
    if "png" in want:
        p = f"{base_path}.png"
        render_png(sheet, p, dpi=dpi, title=title)
        written.append(p)
    return written
