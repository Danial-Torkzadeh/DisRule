"""DisRule - a generator for foldable statistical slide rules."""
from .distributions import DISTRIBUTIONS, P_PRIORITIES
from .layout import RulerConfig, Sheet, build_sheet, validate
from .render import (export_set, render_pdf, render_png, render_png_bytes,
                     render_svg)
from . import tick_engine

__version__ = "1.1.0"

__all__ = [
    "DISTRIBUTIONS", "P_PRIORITIES", "RulerConfig", "Sheet", "build_sheet",
    "validate", "export_set", "render_pdf", "render_png", "render_png_bytes",
    "render_svg", "tick_engine", "__version__",
]
