"""Distribution specifications for DisRule.

Each DistSpec knows how to map values <-> tail probabilities, which tail it
uses (left-tail CDF for symmetric rules, right-tail survival for chi-square
and F), how to build df tags, and what the sensible defaults are.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from . import distmath

# Probabilities emphasized on every P line (the alpha-relevant values).
P_PRIORITIES = (0.001, 0.005, 0.01, 0.025, 0.05, 0.1,
                0.9, 0.95, 0.975, 0.99, 0.995, 0.999)


def _g(x):
    """Format a df number compactly (7 not 7.0, 2.5 stays 2.5)."""
    return str(int(round(x))) if abs(x - round(x)) < 1e-9 else f"{x:g}"


@dataclass(frozen=True)
class DistSpec:
    key: str
    name: str            # full display name
    needs_df: bool
    dfs_per_line: int    # 0 = none, 1 = single df, 2 = (d1, d2)
    tail: str            # "left" -> P = CDF(v), "right" -> P = 1 - CDF(v)
    symmetric: bool      # True for normal / t (allows a +/- split rule)

    # ---- core mappings -------------------------------------------------
    def _dist(self, dfs):
        if self.key == "normal":
            return distmath.Normal()
        if self.key == "t":
            return distmath.StudentT(dfs[0])
        if self.key == "chi2":
            return distmath.Chi2(dfs[0])
        if self.key == "f":
            return distmath.F(dfs[0], dfs[1])
        raise KeyError(self.key)

    def p_of_value(self, v, dfs):
        """Tail probability used to position a value on the sheet."""
        d = self._dist(dfs)
        return float(d.cdf(v)) if self.tail == "left" else float(d.sf(v))

    def value_of_p(self, p, dfs):
        """Inverse of p_of_value."""
        d = self._dist(dfs)
        p = min(max(p, 1e-12), 1 - 1e-12)
        return float(d.ppf(p)) if self.tail == "left" else float(d.isf(p))

    # ---- defaults ------------------------------------------------------
    def default_dfs(self):
        if self.key == "t":
            return (7.0, 14.0, 28.0, 35.0)
        if self.key == "chi2":
            return (3.0, 7.0, 15.0, 30.0)
        if self.key == "f":
            return (2.0, 8.0, 4.0, 12.0, 8.0, 20.0, 12.0, 30.0)
        return ()

    def default_value_range(self):
        return {"normal": (-4.0, 4.0), "t": (-5.0, 5.0),
                "chi2": (0.0, 40.0), "f": (0.0, 5.0)}[self.key]

    # ---- tags and priorities --------------------------------------------
    def df_tag(self, dfs):
        if self.key == "f":
            return f"F({_g(dfs[0])}, {_g(dfs[1])})"
        if self.key in ("t", "chi2"):
            return f"df = {_g(dfs[0])}"
        return ""

    def value_priorities(self, lo, hi):
        """Round 'anchor' values that get a heavier mark when they fall on
        the line (integers for z/t, x5 chi-square values, integers for F)."""
        out = []
        if lo > hi:
            return out
        if self.key in ("normal", "t"):
            k = math.ceil(lo - 1e-9)
            while k <= hi + 1e-9:
                out.append(float(k))
                k += 1
        elif self.key == "chi2":
            k = 1.0
            while k <= hi + 1e-9:
                if k >= lo - 1e-9 and (k <= 10.0 or abs(k % 5.0) < 1e-9):
                    out.append(float(k))
                k += 1.0
        elif self.key == "f":
            k = 0.5
            while k <= hi + 1e-9:
                if k >= lo - 1e-9:
                    out.append(float(k))
                k += 0.5
        return out

    def auto_title(self, front_tags, back_tags):
        tail_txt = "P = 1 - CDF (right tail)" if self.tail == "right" \
            else "P = CDF (left tail)"
        if self.key == "normal":
            return (f"Normal (z) DisRule  |  front: +z side  |  "
                    f"back: -z side  |  {tail_txt}")
        ft = ", ".join(front_tags)
        bt = ", ".join(back_tags)
        return (f"{self.name} DisRule  |  front: {ft}  |  back: {bt}  |  "
                f"{tail_txt}")


NORMAL = DistSpec("normal", "Normal (z)", False, 0, "left", True)
T = DistSpec("t", "Student t", True, 1, "left", True)
CHI2 = DistSpec("chi2", "Chi-square", True, 1, "right", False)
F = DistSpec("f", "F distribution", True, 2, "right", False)

DISTRIBUTIONS = {s.key: s for s in (NORMAL, T, CHI2, F)}
