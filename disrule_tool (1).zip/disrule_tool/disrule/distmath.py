"""Pure-Python statistics for DisRule -- no numpy/scipy needed.

Implements the four distributions the ruler supports (normal, Student t,
chi-square, F) with cdf / sf / ppf / isf, using classical algorithms:

- regularized incomplete beta  (modified Lentz continued fraction)
- regularized incomplete gamma (series + continued fraction)
- normal ppf via Acklam's rational approximation + one Halley refinement
- inverse quantiles via bracketed safeguarded Newton (rtsafe)

All functions are accurate to ~1e-12 or better over the ranges DisRule
uses (p in [1e-6, 1-1e-6], df up to several hundred).
"""
from __future__ import annotations

import math

# ==========================================================================
# special functions
# ==========================================================================

def _betacf(a, b, x):
    """Continued fraction for the incomplete beta (modified Lentz)."""
    MAXIT, EPS, FPMIN = 300, 3e-16, 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return h


def betainc(a, b, x):
    """Regularized incomplete beta function I_x(a, b)."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    ln_bt = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
             + a * math.log(x) + b * math.log1p(-x))
    bt = math.exp(ln_bt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def _gamma_series(a, x):
    """Regularized P(a, x) by series (valid for x < a + 1)."""
    ap = a
    summ = 1.0 / a
    delt = summ
    for _ in range(600):
        ap += 1.0
        delt *= x / ap
        summ += delt
        if abs(delt) < abs(summ) * 3e-16:
            break
    return summ * math.exp(-x + a * math.log(x) - math.lgamma(a))


def _gamma_cf(a, x):
    """Regularized Q(a, x) by continued fraction (valid for x >= a + 1)."""
    FPMIN = 1e-300
    b = x + 1.0 - a
    c = 1.0 / FPMIN
    d = 1.0 / b
    h = d
    for i in range(1, 600):
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        if abs(d) < FPMIN:
            d = FPMIN
        c = b + an / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < 3e-16:
            break
    return math.exp(-x + a * math.log(x) - math.lgamma(a)) * h


def gammainc_P(a, x):
    """Regularized lower incomplete gamma P(a, x)."""
    if x <= 0.0:
        return 0.0
    if x < a + 1.0:
        return _gamma_series(a, x)
    return 1.0 - _gamma_cf(a, x)


def gammainc_Q(a, x):
    """Regularized upper incomplete gamma Q(a, x) = 1 - P(a, x)."""
    if x <= 0.0:
        return 1.0
    if x < a + 1.0:
        return 1.0 - _gamma_series(a, x)
    return _gamma_cf(a, x)


# ==========================================================================
# normal distribution
# ==========================================================================

_SQRT2 = math.sqrt(2.0)
_SQRT2PI = math.sqrt(2.0 * math.pi)


def norm_cdf(x):
    return 0.5 * math.erfc(-x / _SQRT2)


def norm_sf(x):
    return 0.5 * math.erfc(x / _SQRT2)


def norm_pdf(x):
    return math.exp(-0.5 * x * x) / _SQRT2PI


def norm_ppf(p):
    """Acklam's rational approximation + one Halley refinement step."""
    if p <= 0.0:
        return -8.3
    if p >= 1.0:
        return 8.3
    a = (-3.969683028665376e+01, 2.209460984245205e+02,
         -2.759285104469687e+02, 1.383577518672690e+02,
         -3.066479806614716e+01, 2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02,
         -1.556989798598866e+02, 6.680131188771972e+01,
         -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01,
         -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00, 2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01,
         2.445134137142996e+00, 3.754408661907416e+00)
    p_low, p_high = 0.02425, 1 - 0.02425
    if p < p_low:
        q = math.sqrt(-2 * math.log(p))
        x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q
             + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    elif p <= p_high:
        q = p - 0.5
        r = q * q
        x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r
             + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r
                            + b[4]) * r + 1)
    else:
        q = math.sqrt(-2 * math.log(1 - p))
        x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q
              + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    # two Halley refinement steps -> ~machine precision over the full range
    for _ in range(2):
        e = norm_cdf(x) - p
        u = e * _SQRT2PI * math.exp(0.5 * x * x)
        x = x - u / (1.0 + 0.5 * x * u)
    return x


# ==========================================================================
# generic bracketed safeguarded Newton root finder (rtsafe)
# ==========================================================================

def _rtsafe(f, x1, x2, xacc=1e-13, maxit=120):
    """Find root of f in [x1, x2]; f returns (value, derivative).

    xacc is a RELATIVE tolerance: iteration stops once the step is below
    xacc * max(1, |x|).
    """
    fl, dfl = f(x1)
    fh, dfh = f(x2)
    if fl == 0.0:
        return x1
    if fh == 0.0:
        return x2
    if fl * fh > 0.0:
        raise ValueError("root not bracketed")
    xl, xh = (x1, x2) if fl < 0.0 else (x2, x1)
    rts = 0.5 * (x1 + x2)
    dxold = abs(x2 - x1)
    dx = dxold
    fr, dfr = f(rts)
    for _ in range(maxit):
        if (((rts - xh) * dfr - fr) * ((rts - xl) * dfr - fr) > 0.0
                or abs(2.0 * fr) > abs(dxold * dfr)):
            dxold = dx
            dx = 0.5 * (xh - xl)
            rts = xl + dx
            if xl == rts or xh == rts:
                return rts
        else:
            dxold = dx
            dx = fr / dfr
            temp = rts
            rts -= dx
            if temp == rts:
                return rts
        if abs(dx) < xacc * max(1.0, abs(rts)):
            return rts
        fr, dfr = f(rts)
        if fr < 0.0:
            xl = rts
        else:
            xh = rts
    return rts


def _expand_bracket(f, a, b, grow=200):
    """Widen [a, b] additively (doubling the width) until f changes sign.

    Sign-safe: works whether the bounds are negative (t quantiles) or
    positive (chi2 / F quantiles) and reaches very far tails (the t rule
    with df = 1 has quantiles beyond +-600 at p = 1e-5).
    """
    fa, fb = f(a)[0], f(b)[0]
    for _ in range(grow):
        if fa == 0.0:
            return a, a
        if fb == 0.0:
            return b, b
        if fa * fb <= 0.0:
            return a, b
        width = (b - a) or 1.0
        a -= width
        b += width
        fa, fb = f(a)[0], f(b)[0]
    raise ValueError("could not bracket the quantile")


# ==========================================================================
# the four distributions (uniform cdf / sf / ppf / isf interface)
# ==========================================================================

class Normal:
    key = "normal"

    def cdf(self, x):
        return norm_cdf(x)

    def sf(self, x):
        return norm_sf(x)

    def pdf(self, x):
        return norm_pdf(x)

    def ppf(self, p):
        return norm_ppf(p)

    def isf(self, p):
        return norm_ppf(1.0 - p)


class StudentT:
    key = "t"

    def __init__(self, df):
        self.df = float(df)

    def _sf_pos(self, t):
        """P(T > t) for t >= 0 via the incomplete beta."""
        x = self.df / (self.df + t * t)
        return 0.5 * betainc(0.5 * self.df, 0.5, x)

    def cdf(self, x):
        if x == 0.0:
            return 0.5
        return 1.0 - self._sf_pos(x) if x > 0 else self._sf_pos(-x)

    def sf(self, x):
        if x == 0.0:
            return 0.5
        return self._sf_pos(x) if x > 0 else 1.0 - self._sf_pos(-x)

    def pdf(self, x):
        df = self.df
        c = math.exp(math.lgamma(0.5 * (df + 1)) - math.lgamma(0.5 * df)) \
            / math.sqrt(df * math.pi)
        return c * (1.0 + x * x / df) ** (-0.5 * (df + 1))

    def ppf(self, p):
        p = min(max(p, 1e-15), 1 - 1e-15)
        if p == 0.5:
            return 0.0
        # solve in the tail where the probability is small (best precision)
        if p < 0.5:
            target = p

            def f(x):
                return (self.cdf(x) - target, self.pdf(x))
        else:
            target = 1.0 - p

            def f(x):
                return (self.sf(x) - target, -self.pdf(x))
        seed = norm_ppf(p) * max(1.0, min(3.0, math.sqrt(self.df / 4.0)))
        lo, hi = _expand_bracket(f, min(seed, -0.5), max(seed, 0.5))
        return _rtsafe(f, lo, hi)

    def isf(self, p):
        return self.ppf(1.0 - p)


class Chi2:
    key = "chi2"

    def __init__(self, df):
        self.df = float(df)
        self._a = 0.5 * float(df)

    def cdf(self, x):
        return gammainc_P(self._a, 0.5 * x)

    def sf(self, x):
        return gammainc_Q(self._a, 0.5 * x)

    def pdf(self, x):
        if x <= 0.0:
            return 0.0
        a = self._a
        return math.exp((a - 1.0) * math.log(x) - 0.5 * x
                        - a * math.log(2.0) - math.lgamma(a))

    def ppf(self, p):
        p = min(max(p, 1e-15), 1 - 1e-15)
        if p <= 0.0:
            return 0.0
        # Wilson-Hilferty seed
        z = norm_ppf(p)
        a = self._a
        wh = 1.0 - 2.0 / (9.0 * self.df) + z * math.sqrt(2.0 / (9.0 * self.df))
        seed = max(1e-6, self.df * wh ** 3)

        def f(x):
            return (self.cdf(x) - p, self.pdf(x))
        if p > 0.5:
            def f(x):
                return (self.sf(x) - (1.0 - p), -self.pdf(x))
        lo, hi = _expand_bracket(f, seed * 0.25, max(seed * 4.0, 1.0))
        return _rtsafe(f, lo, hi)

    def isf(self, p):
        return self.ppf(1.0 - p)


class F:
    key = "f"

    def __init__(self, d1, d2):
        self.d1 = float(d1)
        self.d2 = float(d2)
        self._a = 0.5 * float(d1)
        self._b = 0.5 * float(d2)

    def cdf(self, x):
        if x <= 0.0:
            return 0.0
        xx = self.d1 * x / (self.d1 * x + self.d2)
        return betainc(self._a, self._b, xx)

    def sf(self, x):
        if x <= 0.0:
            return 1.0
        xx = self.d2 / (self.d2 + self.d1 * x)
        return betainc(self._b, self._a, xx)

    def pdf(self, x):
        if x <= 0.0:
            return 0.0
        a, b = self._a, self._b
        # f(x) = 1/B(a,b) (d1/d2)^a x^(a-1) (1 + d1 x/d2)^-(a+b)
        lg = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b))
        ln_f = (lg + a * math.log(self.d1 / self.d2)
                + (a - 1.0) * math.log(x)
                - (a + b) * math.log1p(self.d1 * x / self.d2))
        return math.exp(ln_f) if ln_f < 709.0 else 1e308

    def ppf(self, p):
        p = min(max(p, 1e-15), 1 - 1e-15)
        if p <= 0.0:
            return 0.0
        seed = 1.0

        def f(x):
            return (self.cdf(x) - p, self.pdf(x))
        if p > 0.5:
            def f(x):
                return (self.sf(x) - (1.0 - p), -self.pdf(x))
        lo, hi = _expand_bracket(f, seed * 0.05, max(seed * 20.0, 2.0))
        return _rtsafe(f, lo, hi)

    def isf(self, p):
        return self.ppf(1.0 - p)
