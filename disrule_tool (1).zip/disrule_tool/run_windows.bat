@echo off
setlocal EnableExtensions
title DisRule
cd /d "%~dp0"

echo.
echo  ------------------------------------------------------------
echo   DisRule launcher
echo  ------------------------------------------------------------
echo.

python --version >nul 2>nul
if errorlevel 1 goto trypy
set PYCMD=python
goto checklibs

:trypy
py --version >nul 2>nul
if errorlevel 1 goto nopython
set PYCMD=py
goto checklibs

:checklibs
%PYCMD% -c "import reportlab, PIL" >nul 2>nul
if errorlevel 1 goto pip
goto startapp

:pip
echo One-time setup - downloading 2 small helper libraries
echo -about 15 MB, kept INSIDE Python, not in this folder.
echo This takes well under a minute. Please wait...
echo.
%PYCMD% -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto venv
goto startapp

:venv
echo.
echo Direct install was blocked - using a local setup folder instead.
%PYCMD% -m venv .venv
if errorlevel 1 goto venvfail
".venv\Scripts\python.exe" -m pip install --quiet --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto pipfail
set VENVPY=".venv\Scripts\python.exe"
goto startapp2

:startapp
set VENVPY=%PYCMD%

:startapp2
echo.
echo Starting DisRule - the dashboard will open shortly.
echo Keep this black window open while you use DisRule.
%VENVPY% disrule_app.py
if errorlevel 1 goto appfail
goto end

:nopython
echo.
echo  ============================================================
echo   Python is not installed yet - one-time setup:
echo.
echo   1. Open  https://www.python.org/downloads/
echo   2. Click the big yellow Download Python button.
echo   3. Run the installer.
echo   4. IMPORTANT: on the first installer screen, tick the box
echo      "Add python.exe to PATH" - it is near the bottom.
echo   5. When it finishes, double-click this file again.
echo.
echo   Alternative: install "Python 3" from the Microsoft Store.
echo  ============================================================
echo.
echo Press any key to close this window...
pause >nul
exit /b

:venvfail
echo.
echo SETUP PROBLEM: the setup folder could not be created.
echo Take a screenshot of this whole window and send it
echo to your assistant.
pause >nul
exit /b

:pipfail
echo.
echo DOWNLOAD PROBLEM: the helper libraries could not be installed.
echo 1. Check your internet connection.
echo 2. Double-click this file again.
echo If it keeps failing, take a screenshot of this window
echo and send it to your assistant.
pause >nul
exit /b

:appfail
echo.
echo DisRule stopped with an error.
echo Take a screenshot of this whole window and send it
echo to your assistant.
pause >nul
exit /b

:end
exit /b
